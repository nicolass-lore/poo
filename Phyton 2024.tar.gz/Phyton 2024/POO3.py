class Deporte:
    def __init__(self,iddeporte,pelota,arco,jugadores):
        self.iddeporte=iddeporte
        self.pelota=pelota
        self.arco=arco
        self.jugadores=jugadores
    def mostrar(self):
        print("cod Deporte:",self.iddeporte,"pelota:",self.pelota,"arco:",self.arco,"jugadores:",self.jugadores)
Deportel1=Deporte(1,"redonda","no tiene arco","altos y bajos")#cree el primer objeto
Deportel2=Deporte(2,"redonda","alto2,14,ancho3,66","altos y bajos")#cree el segundo objeto
Deportel3=Deporte(3,"redonda","alto2,44,ancho7,32","altos y bajos")#cree el tercer objeto
Deportel1.mostrar()
Deportel2.mostrar()
Deportel3.mostrar()

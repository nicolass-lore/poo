rta="si"
while rta=="si":
    opcion=int(input("menu opciones \n1 decir hola.\n2 decir chau.\n3 decir espere."))
    if opcion==1:
        print("hola")
    elif opcion==2:
        print("chau")
    elif opcion==3:
        print("espere     ")
    else:
        print("opcion invalida")
    rta=input("desea volver a menu? si o no:")
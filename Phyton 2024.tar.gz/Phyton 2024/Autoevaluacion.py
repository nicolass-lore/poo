continuar=True


lacteo=["yogurt","leche","manteca","queso"]


carnes=["choriso","molida","matambre","vacio"]


verduras=["lechuga","tomate","remolacha","peregil"]


legumbres=["arbeja","lenteja","garbanso","soja"]


while continuar:


 menu=input("1-cargar productos   2-mostrar productos en stock:  ")
 if menu=="1":
    productos=input("Que productos desea cargar: 1-Lacteos  2-Carnes  3-Verduras  4-Legumbres: ")
   
    if productos=="1":
        lac=input("ingrese el producto: ")
   
        lacteo.append(lac)
   
    elif productos=="2":
        car=input("ingrese el producto: ")


        carnes.append(car)
   
    elif productos=="3":
        verd=input("ingrese el producto: ")


        verduras.append(verd)


    elif productos=="4":
        legum=input("ingrese el producto: ")


        legumbres.append(legum)


 elif menu=="2":
    mostrar=input("que productos desea mostrar  1-Lacteos  2-Carnes  3-Verduras  4-Legumbres:   ")
    if mostrar=="1":
        print(lacteo)
   
    elif mostrar=="2":
        print(carnes)


    elif mostrar=="3":
        print(verduras)


    elif mostrar=="4":
        print(legumbres)


 sigue=input("desea continuar si o no:  ")
 if sigue=="si":
   print()
 elif sigue=="no":
    continuar=0

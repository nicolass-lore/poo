class Vehiculo:
    def __init__(self,idVehiculo,marca,modelo,año,):
        self.idVehiculo=idVehiculo
        self.marca=marca
        self.modelo=modelo
        self.año=año
    def mostrar(self):
        print("cod Veiculo:",self.idVehiculo,"marca:",self.marca,"modelo:",self.modelo,"año:",self.año)
Vehiculol1=Vehiculo(1,"Ferrari","625 LM","1956")#cree el primer objeto
Vehiculol2=Vehiculo(2,"Lamborghini","URUS PERFORMANTE","2023")#cree el segundo objeto
Vehiculol3=Vehiculo(3,"Bugatti","type 101","1951")#cree el tercer objeto
Vehiculol1.mostrar()
Vehiculol2.mostrar()
Vehiculol3.mostrar()

class Auto(Vehiculo):
  def __init__(self,marca,modelo,año,motor,marchas,tiponafta,):
        Vehiculo.__init__(self,marca,modelo,año,motor,)
        self.motor=motor
        self. marchas=marchas 
        self.tiponafta=tiponafta
  def printname(self):
    print(self.motor,self.marchas,self.tiponafta,)
    super().printname()

class Motocicleta(Vehiculo):
  def __init__(self,marca,modelo,año,motor,marchas,tiponafta,):
        Vehiculo.__init__(self,marca,modelo,año,motor,)
        self.motor=motor
        self. marchas=marchas 
        self.tiponafta=tiponafta
  def printname(self):
    print(self.motor,self.marchas,self.tiponafta,)
    super().printname()

class Camion(Vehiculo):
  def __init__(self,marca,modelo,año,motor,marchas,tiponafta,):
        Vehiculo.__init__(self,marca,modelo,año,motor,)
        self.motor=motor
        self. marchas=marchas 
        self.tiponafta=tiponafta
  def printname(self):
      super().__init__(marca, modelo, año)
        self.capacidad_carga = capacidad_carga

x1= Auto("Ferrari", "625 LM",1956)
x1.printname()
x2 = Motocicleta("kawasaki","Vulcan 900",2006,"V-Twin","5 velocidades","gasolina")
x2.printname()
x3 = Camion("iveco","eurocargo",1991,"capacidad de carga de 6 a 15 tonelaadas")
x3.printname()


    


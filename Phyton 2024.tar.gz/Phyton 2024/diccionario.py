diccolores={"amarillo":"primario","rojo":"primario","azul":"primario","blanco":"primario"}
for c,v in diccolores.items():
    print("el color es:",c," y es:",v)
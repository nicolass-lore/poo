peso=float(input("INGRESE PESO:"))
print("el peso ingresado es de:",peso)
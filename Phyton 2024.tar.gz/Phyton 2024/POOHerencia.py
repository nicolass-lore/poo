class Person:
  def __init__(self, fname, lname, dni, direccion, codigopostal):
    self.firstname = fname
    self.lastname = lname
    self.dni = dni
    self.direccion = direccion
    self.codigopostal = codigopostal

  def printname(self):
    print(self.firstname, self.lastname, self.dni, self.direccion, self.codigopostal )


class Student(Person):
  def __init__(self, fname, lname, dni, direccion, codigopostal,matrícula, curso, estado,añoingreso):
        Person.__init__(self, fname, lname, dni, direccion, codigopostal)
        self.matricula=matrícula
        self. curso=curso 
        self.estado=estado
        self.añoingreso=añoingreso
  def printname(self):
    print(self.matricula,self.curso,self.estado,self.añoingreso)
    super().printname()


   
x1 = Student("Juana", "León",657489,"Puerto Iguazu 2035",5280,30333,"5año","regular",2021)
x1.printname()


x2 = Student("Pedro", "Lopez",564833,"Puerto Iguazu 2635",5280,2350,"4año","regular",2019)
x2.printname()

x3 = Student("Ana", "Martinez",345699,"Puerto Iguazu 4335",5280,6754,"6años","regular",2018)
x3.printname()

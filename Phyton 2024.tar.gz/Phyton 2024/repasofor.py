colores=["rojo","verde","azul"]
for c in colores:
    print("colores en la lista:",c)
    
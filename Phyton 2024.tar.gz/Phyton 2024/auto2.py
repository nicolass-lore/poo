class Vehiculo:
    def __init__(self, idVehiculo, marca, modelo, año):
        self.idVehiculo = idVehiculo
        self.marca = marca
        self.modelo = modelo
        self.año = año
    
    def mostrar(self):
        print(f"Cod Vehiculo: {self.idVehiculo}, Marca: {self.marca}, Modelo: {self.modelo}, Año: {self.año}")


class Auto(Vehiculo):
    def __init__(self, idVehiculo, marca, modelo, año, motor, marchas, tiponafta):
        super().__init__(idVehiculo, marca, modelo, año)
        self.motor = motor
        self.marchas = marchas
        self.tiponafta = tiponafta
    
    def printname(self):
        super().mostrar()
        print(f"Motor: {self.motor}, Marchas: {self.marchas}, Tipo de Nafta: {self.tiponafta}")


class Motocicleta(Vehiculo):
    def __init__(self, idVehiculo, marca, modelo, año, motor, marchas, tiponafta):
        super().__init__(idVehiculo, marca, modelo, año)
        self.motor = motor
        self.marchas = marchas
        self.tiponafta = tiponafta
    
    def printname(self):
        super().mostrar()
        print(f"Motor: {self.motor}, Marchas: {self.marchas}, Tipo de Nafta: {self.tiponafta}")


class Camion(Vehiculo):
    def __init__(self, idVehiculo, marca, modelo, año, capacidad_carga):
        super().__init__(idVehiculo, marca, modelo, año)
        self.capacidad_carga = capacidad_carga
    
    def printname(self):
        super().mostrar()
        print(f"Capacidad de Carga: {self.capacidad_carga}")


# Creación de instancias y prueba del código
Vehiculo1 = Vehiculo(1, "Ferrari", "625 LM", "1956")
Vehiculo2 = Vehiculo(2, "Lamborghini", "URUS PERFORMANTE", "2023")
Vehiculo3 = Vehiculo(3, "Bugatti", "Type 101", "1951")

Vehiculo1.mostrar()
Vehiculo2.mostrar()
Vehiculo3.mostrar()

Auto1 = Auto(4, "Ferrari", "625 LM", "1956", "V12", "7 velocidades", "gasolina")
Motocicleta1 = Motocicleta(5, "Kawasaki", "Vulcan 900", "2006", "V-Twin", "5 velocidades", "gasolina")
Camion1 = Camion(6, "Iveco", "Eurocargo", "1991", "capacidad de carga de 6 a 15 toneladas")

Auto1.printname()
Motocicleta1.printname()
Camion1.printname()